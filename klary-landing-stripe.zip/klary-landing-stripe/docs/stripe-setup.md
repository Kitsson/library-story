# KLARY Landing Page + Stripe Subscription Setup

## Files Included

1. **index.html** - Landing page with Stripe Checkout integration
2. **stripe.ts** - Backend routes for Stripe (add to your backend)
3. **prisma-additions.txt** - Database schema updates
4. **.env.example** - Environment variables template
5. **vercel.json** - Vercel deployment config

## Setup Steps

### 1. Stripe Dashboard Setup

1. Go to [Stripe Dashboard](https://dashboard.stripe.com)
2. Create 6 Products with recurring prices:
   - KlarStart Monthly (795 SEK)
   - KlarStart Yearly (636 SEK/month, billed annually)
   - KlarPro Monthly (1,495 SEK)
   - KlarPro Yearly (1,196 SEK/month, billed annually)
   - KlarFirm Monthly (3,995 SEK)
   - KlarFirm Yearly (3,196 SEK/month, billed annually)
3. Copy the Price IDs (they start with `price_`)
4. Get your API keys from Developers > API keys
5. Create a webhook endpoint pointing to: `https://your-backend.railway.app/api/stripe/webhook`
   - Select events: `checkout.session.completed`, `invoice.payment_succeeded`, `invoice.payment_failed`, `customer.subscription.deleted`

### 2. Backend Setup

1. Install Stripe SDK:
   ```bash
   npm install stripe
   ```

2. Add the `stripe.ts` routes to your backend (e.g., `src/routes/stripe.ts`)

3. Update your `server.ts` to include:
   ```typescript
   import stripeRoutes from './routes/stripe';
   app.use('/api/stripe', stripeRoutes);
   ```

4. Update your Prisma schema with the Organization model

5. Run Prisma migration:
   ```bash
   npx prisma migrate dev --name add_subscriptions
   ```

6. Add environment variables to Railway (from .env.example)

### 3. Landing Page Setup

1. Update `CONFIG` in index.html:
   ```javascript
   const CONFIG = {
     API_URL: 'https://your-backend.railway.app',
     STRIPE_PUBLIC_KEY: 'pk_live_your_actual_key',
     APP_REGISTER_URL: 'https://your-backend.railway.app/register'
   };
   ```

2. Deploy to Vercel:
   ```bash
   npm i -g vercel
   vercel
   ```

### 4. Post-Payment Flow

After successful payment:
1. Customer is redirected to `/register?session_id=xxx`
2. Your register page should:
   - Call `/api/stripe/subscription-status?sessionId=xxx` to verify payment
   - Show registration form
   - Create user account linked to the organization
3. Welcome email is sent automatically (implement in webhook handler)

## Testing

Use Stripe test cards:
- Success: `4242 4242 4242 4242`
- Decline: `4000 0000 0000 0002`
- Any future expiry date, any 3-digit CVC, any ZIP
