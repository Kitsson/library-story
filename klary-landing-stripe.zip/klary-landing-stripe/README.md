# KLARY Landing Page + Stripe Subscription

Complete setup for KLARY accounting app landing page with Stripe subscription payments.

## Quick Start

1. **Read `docs/stripe-setup.md`** for full instructions
2. **Give `CLAUDE-CODE-PROMPT.md` to Claude Code** to automate setup
3. **Update `landing-page/index.html`** CONFIG section with your URLs

## Folder Structure
```
├── landing-page/
│   ├── index.html          # Landing page with Stripe Checkout
│   └── vercel.json         # Vercel deployment config
├── backend/
│   ├── routes/
│   │   └── stripe.ts       # Stripe API routes
│   ├── prisma/
│   │   └── schema-additions.prisma  # DB schema updates
│   └── .env.example        # Environment variables template
├── docs/
│   └── stripe-setup.md     # Step-by-step setup guide
└── CLAUDE-CODE-PROMPT.md   # Prompt for Claude Code automation
```

## Deployment
- **Landing Page**: Vercel (static hosting)
- **Backend**: Railway (already deployed)
- **Database**: PostgreSQL via Railway
- **Payments**: Stripe

## Support
For questions, refer to `docs/stripe-setup.md` or ask Claude Code to read `CLAUDE-CODE-PROMPT.md`.
