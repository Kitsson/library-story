# Claude Code Setup Instructions

## Context
Setting up Stripe subscription payments for KLARY - Scandinavian Accounting Automation Suite.

## Files in This Repo
- `landing-page/` - Static landing page with Stripe Checkout integration
- `backend/routes/stripe.ts` - Express routes for Stripe API
- `backend/prisma/schema-additions.prisma` - Database schema updates
- `backend/.env.example` - Required environment variables
- `docs/stripe-setup.md` - Full setup guide

## What Needs To Be Done

### 1. Backend Integration
- Install `stripe` npm package
- Add `stripe.ts` routes to the Express server
- Update Prisma schema with Organization model
- Run migration
- Add environment variables to Railway

### 2. Stripe Dashboard Setup
- Create 6 products with recurring prices (monthly + yearly for 3 plans)
- Configure webhook endpoint
- Get API keys

### 3. Landing Page Deployment
- Update CONFIG values in index.html
- Deploy to Vercel

### 4. Post-Payment Flow
- Register page reads session_id from URL
- Verifies payment with backend
- Creates user account
- Sends welcome email

## Current Backend URL
Replace `YOUR_BACKEND_URL` in all files with actual Railway URL.

## Tech Stack
- Backend: Node.js + Express + TypeScript + Prisma + PostgreSQL
- Frontend: Static HTML/CSS (deployed to Vercel)
- Payments: Stripe Checkout + Stripe Billing
- Email: SendGrid (optional)
