import { Router } from 'express';
import Stripe from 'stripe';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-12-18.acacia',
});

// Price IDs - Set these in your Stripe Dashboard
const PRICE_IDS = {
  monthly: {
    klarstart: process.env.STRIPE_PRICE_KLARSTART_MONTHLY!,
    klarpro: process.env.STRIPE_PRICE_KLARPRO_MONTHLY!,
    klarfirm: process.env.STRIPE_PRICE_KLARFIRM_MONTHLY!,
  },
  yearly: {
    klarstart: process.env.STRIPE_PRICE_KLARSTART_YEARLY!,
    klarpro: process.env.STRIPE_PRICE_KLARPRO_YEARLY!,
    klarfirm: process.env.STRIPE_PRICE_KLARFIRM_YEARLY!,
  }
};

// Create checkout session
router.post('/create-checkout-session', async (req, res) => {
  try {
    const { plan, billing, email } = req.body;

    const priceId = PRICE_IDS[billing as keyof typeof PRICE_IDS]?.[plan as keyof typeof PRICE_IDS.monthly];

    if (!priceId) {
      return res.status(400).json({ error: 'Invalid plan or billing cycle' });
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      billing_address_collection: 'required',
      customer_email: email,
      line_items: [{
        price: priceId,
        quantity: 1,
      }],
      mode: 'subscription',
      success_url: `${process.env.APP_URL}/register?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.APP_URL}/pricing?canceled=true`,
      metadata: {
        plan,
        billing,
      },
      subscription_data: {
        trial_period_days: 14,
        metadata: {
          plan,
          billing,
        }
      }
    });

    res.json({ sessionId: session.id });
  } catch (error) {
    console.error('Stripe checkout error:', error);
    res.status(500).json({ error: 'Failed to create checkout session' });
  }
});

// Webhook handler for Stripe events
router.post('/webhook', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET!;

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig as string, endpointSecret);
  } catch (err: any) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle events
  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session;

      // Create pending organization
      await prisma.organization.create({
        data: {
          name: session.customer_details?.name || 'New Firm',
          email: session.customer_email!,
          stripeCustomerId: session.customer as string,
          stripeSubscriptionId: session.subscription as string,
          plan: session.metadata?.plan || 'klarstart',
          billing: session.metadata?.billing || 'monthly',
          status: 'TRIAL',
          trialEndsAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
        }
      });

      // TODO: Send welcome email with setup instructions
      console.log('New subscription created for:', session.customer_email);
      break;
    }

    case 'invoice.payment_succeeded': {
      const invoice = event.data.object as Stripe.Invoice;
      // Update organization status to ACTIVE
      await prisma.organization.updateMany({
        where: { stripeCustomerId: invoice.customer as string },
        data: { status: 'ACTIVE' }
      });
      break;
    }

    case 'invoice.payment_failed': {
      const failedInvoice = event.data.object as Stripe.Invoice;
      // Mark organization as PAYMENT_FAILED
      await prisma.organization.updateMany({
        where: { stripeCustomerId: failedInvoice.customer as string },
        data: { status: 'PAYMENT_FAILED' }
      });
      break;
    }

    case 'customer.subscription.deleted': {
      const subscription = event.data.object as Stripe.Subscription;
      // Mark organization as CANCELLED
      await prisma.organization.updateMany({
        where: { stripeSubscriptionId: subscription.id },
        data: { status: 'CANCELLED' }
      });
      break;
    }
  }

  res.json({ received: true });
});

// Get subscription status
router.get('/subscription-status', async (req, res) => {
  try {
    const { sessionId } = req.query;

    const session = await stripe.checkout.sessions.retrieve(sessionId as string);
    const subscription = await stripe.subscriptions.retrieve(session.subscription as string);

    res.json({
      status: subscription.status,
      plan: session.metadata?.plan,
      billing: session.metadata?.billing,
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to get subscription status' });
  }
});

export default router;
